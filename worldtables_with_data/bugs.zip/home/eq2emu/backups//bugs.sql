-- Table: `bugs`
USE `eq2emu`;
SET FOREIGN_KEY_CHECKS=0;

/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.11-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: eq2emu
-- ------------------------------------------------------
-- Server version	10.11.11-MariaDB-0+deb12u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bugs`
--

DROP TABLE IF EXISTS `bugs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bugs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_id` int(10) unsigned NOT NULL DEFAULT 0,
  `player` varchar(64) NOT NULL DEFAULT ' ',
  `category` varchar(64) NOT NULL DEFAULT ' ',
  `subcategory` varchar(64) NOT NULL DEFAULT ' ',
  `causes_crash` varchar(64) NOT NULL DEFAULT ' ',
  `reproducible` varchar(64) NOT NULL DEFAULT ' ',
  `summary` varchar(128) NOT NULL DEFAULT ' ',
  `description` text NOT NULL,
  `version` varchar(32) NOT NULL DEFAULT ' ',
  `spawn_name` varchar(64) NOT NULL DEFAULT 'N/A',
  `spawn_id` int(10) unsigned NOT NULL DEFAULT 0,
  `bug_datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `zone_id` int(10) unsigned NOT NULL DEFAULT 0,
  `copied` int(10) unsigned NOT NULL DEFAULT 0,
  `dbversion` int(10) NOT NULL DEFAULT 0,
  `worldversion` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-17 17:23:21

/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.11-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: eq2emu
-- ------------------------------------------------------
-- Server version	10.11.11-MariaDB-0+deb12u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `bugs`
--

LOCK TABLES `bugs` WRITE;
/*!40000 ALTER TABLE `bugs` DISABLE KEYS */;
INSERT INTO `bugs` VALUES
(84,870,'Pazuzu','AutoBug','AutoGenerate','N','Y','SpellCasted without proper spell range set Alin\'s Keening Lamentation ID','SpellCasted without proper spell range set Alin\'s Keening Lamentation ID','CUR','Bubbles',8350005,'2024-04-08 20:20:36',835,0,0,'0.9.6-omiscorpii'),
(85,1363,'Twila','Content','Non-Player Character','Affects gameplay','Always Happens','Sentry Acton has gone MISSING!','Where did he go?! I have to give him a veiled threat on Vemerik\'s behalf!','       546','N/A',0,'2024-04-21 01:28:54',12,0,0,'0.9.6-omiscorpii'),
(86,959,'Niilobert','Content','Quest Related','Affects gameplay','Always Happens','Can\'t progress in class progression from Mage.','I could finish Mage Training pt II, but after that Magister Niksel says its enough for today, which never changes.','       546','Magister Niksel',2310376,'2024-05-11 14:38:41',231,0,0,'0.9.6-omiscorpii'),
(87,940,'Donkeystyle','AutoBug','AutoGenerate','N','Y','SpellCasted without proper spell range set Telamina\'s Pulsating Feedback ID','SpellCasted without proper spell range set Telamina\'s Pulsating Feedback ID','CUR','a Dervish cutthroat',330092,'2024-06-02 04:44:25',33,0,0,'0.9.6-omiscorpii'),
(88,1442,'Istimus','Art','Character','Cosmetic','Always Happens','error','in','         546','a coastal crab',3250068,'2024-06-09 19:44:15',325,0,0,'0.9.6-omiscorpii'),
(89,1442,'Insomnia','Mechanics','Other','Affects gameplay','Sometimes Happens','Exp Debt with no death ',' Exp debt without dying, get it to zero \nnd it goes back up :o','        546','N/A',0,'2024-06-13 20:57:55',841,0,0,'0.9.6-omiscorpii'),
(90,1418,'Ecoune','AutoBug','AutoGenerate','N','Y','SpellCasted without proper spell range set Pick Pocket ID 8237','SpellCasted without proper spell range set Pick Pocket ID 8237','CUR','Garven Tralk',3250020,'2024-06-14 22:12:18',325,0,0,'0.9.6-omiscorpii'),
(91,1483,'Firechild','Mechanics','Combat','Affects gameplay','Always Happens','Experience Debt','Experience debt not going down with gained experience','SOEBuild=12133L','N/A',0,'2024-07-06 10:25:57',827,0,0,'0.9.7-thetascorpii'),
(92,1574,'Girthy','Interface','User Interface','Affects gameplay','Always Happens','Black screen when creating character','I am stuck zoning with a black screen when logging into a fleshly created character. I am able to camp from this, and a milisecond before it goes to the character select screen, my screen un-blacks.','SOEBuild=12133L','N/A',0,'2024-11-02 23:21:00',27,0,0,'0.9.7-thetascorpii-DR2'),
(93,1590,'Herpes','Mechanics','Other','Affects gameplay','Always Happens','dg','my power is minus 4000/390','        546','N/A',0,'2024-11-22 06:27:39',12,0,0,'0.9.8-thetascorpii-DR1'),
(94,1590,'Potato','Content','Quest Related','Affects gameplay','Always Happens','first quest on isle','No weapon rack','       546','Garven Tralk',3250020,'2024-11-22 07:02:48',325,0,0,'0.9.8-thetascorpii-DR1');
/*!40000 ALTER TABLE `bugs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-17 17:23:21

SET FOREIGN_KEY_CHECKS=1;
