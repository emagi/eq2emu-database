-- Table: `broker_items`
USE `eq2emu`;
SET FOREIGN_KEY_CHECKS=0;

/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.11-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: eq2emu
-- ------------------------------------------------------
-- Server version	10.11.11-MariaDB-0+deb12u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `broker_items`
--

DROP TABLE IF EXISTS `broker_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `broker_items` (
  `unique_id` bigint(20) unsigned NOT NULL,
  `character_id` int(10) unsigned NOT NULL,
  `house_id` int(10) unsigned NOT NULL,
  `item_id` bigint(20) unsigned NOT NULL,
  `cost_copper` int(10) unsigned NOT NULL,
  `for_sale` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `inv_slot_id` int(11) NOT NULL,
  `slot_id` smallint(5) unsigned NOT NULL,
  `count` smallint(5) unsigned NOT NULL,
  `from_inventory` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `creator` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`unique_id`,`character_id`),
  KEY `character_id` (`character_id`),
  CONSTRAINT `broker_items_ibfk_1` FOREIGN KEY (`character_id`) REFERENCES `broker_sellers` (`character_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-22  0:00:02

/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.11-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: eq2emu
-- ------------------------------------------------------
-- Server version	10.11.11-MariaDB-0+deb12u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `broker_items`
--

LOCK TABLES `broker_items` WRITE;
/*!40000 ALTER TABLE `broker_items` DISABLE KEYS */;
INSERT INTO `broker_items` VALUES
(21781697,3862,11,5528,8,0,21782009,0,4,1,''),
(21781702,3862,11,4589,56,0,21782009,3,1,1,''),
(21958653,3862,11,20302,18432,0,-5,2,1,0,''),
(21960367,3862,11,20300,18432,0,21782009,2,1,1,''),
(21962080,3862,11,3269,0,0,21782009,1,1,1,''),
(21962081,3862,11,20306,18432,0,0,1,1,1,''),
(21962082,3862,11,20320,0,0,0,2,1,1,''),
(21966017,3862,11,20302,18432,0,-5,1,1,0,''),
(21991670,3862,11,2535,0,0,0,3,1,1,''),
(22167823,3862,11,6740,10000,1,-5,0,3,0,''),
(22183241,3862,11,20904,62,0,0,5,1,1,''),
(22190127,3862,11,6740,0,0,22183241,0,1,1,'');
/*!40000 ALTER TABLE `broker_items` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-22  0:00:02

SET FOREIGN_KEY_CHECKS=1;
