-- Table: `map_data`
USE `eq2emu`;
SET FOREIGN_KEY_CHECKS=0;

/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.11-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: eq2emu
-- ------------------------------------------------------
-- Server version	10.11.11-MariaDB-0+deb12u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `map_data`
--

DROP TABLE IF EXISTS `map_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `map_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `map_id` int(10) unsigned NOT NULL DEFAULT 0,
  `zone_name` varchar(128) DEFAULT NULL,
  `highest` float NOT NULL DEFAULT 0,
  `lowest` float NOT NULL DEFAULT 0,
  `explored_map_name` varchar(255) DEFAULT NULL,
  `unexplored_map_name` varchar(255) DEFAULT NULL,
  `bounds1_x` float NOT NULL DEFAULT 0,
  `bounds1_z` float NOT NULL DEFAULT 0,
  `bounds2_x` float NOT NULL DEFAULT 0,
  `bounds2_z` float NOT NULL DEFAULT 0,
  `bounds3_x` float NOT NULL DEFAULT 0,
  `bounds3_z` float NOT NULL DEFAULT 0,
  `bounds4_x` float NOT NULL DEFAULT 0,
  `bounds4_z` float NOT NULL DEFAULT 0,
  `explored_key` bigint(20) unsigned NOT NULL DEFAULT 0,
  `unexplored_key` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `MapIDX` (`map_id`,`zone_name`,`unexplored_map_name`,`explored_map_name`)
) ENGINE=InnoDB AUTO_INCREMENT=196 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-17 17:23:35

/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.11-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: eq2emu
-- ------------------------------------------------------
-- Server version	10.11.11-MariaDB-0+deb12u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `map_data`
--

LOCK TABLES `map_data` WRITE;
/*!40000 ALTER TABLE `map_data` DISABLE KEYS */;
INSERT INTO `map_data` VALUES
(1,689884944,'fprt_hood04',35,0.5,'NRVOBM/nms/freeportbeggarscourt_explored.dds','NRVOBM/nms/freeportbeggarscourt_unexplored.dds',-225.8,-137.49,181.39,158.88,-225.8,-137.49,181.39,158.88,4800855641399099720,901758263814064518),
(2,624167834,'fprt_hood01',35,0.5,'NRVOBM/nms/freeportbigbend_explored.dds','NRVOBM/nms/freeportbigbend_unexplored.dds',-268.73,-156.94,241.76,233.74,-268.73,-156.94,241.76,233.74,13893361007639750321,13906198626671770666),
(3,3015956135,'darklight_wood',50,0.5,'NRVOBM/nms/dlere_darklight_explored.dds','NRVOBM/nms/dlere_darklight_unexplored.dds',-821.22,-602.32,755.95,579.64,-821.22,-602.32,755.95,579.64,5213882723512802523,15208764082748909030),
(4,1511096826,'fprt_east',35,0.5,'NRVOBM/nms/freeporteast_explored.dds','NRVOBM/nms/freeporteast_unexplored.dds',-12.08,-230.06,526.27,181.38,-12.08,-230.06,526.27,181.38,13725871580277591208,13678307124192906993),
(5,481320594,'fprt_hood05',35,0.5,'NRVOBM/nms/freeportlongshadowalley_explored.dds','NRVOBM/nms/freeportlongshadowalley_unexplored.dds',-185.63,-147.51,165.21,126.03,-185.63,-147.51,165.21,126.03,17184580992826923618,13923871875585603012),
(6,1589367136,'nektulos',100,1,'NRVOBM/nms/nektulos_explored.dds','NRVOBM/nms/nektulos_unexplored.dds',-1377.6,-2504.07,2619.59,525.19,-1377.6,-2504.07,2619.59,525.19,14951901861444459530,13425018927123251987),
(7,3638863494,'neriak',35,0.5,'NRVOBM/nms/neriak_explored.dds','NRVOBM/nms/neriak_unexplored.dds',-337.68,-443.76,933.08,509.84,-337.68,-443.76,933.08,509.84,4025380289632629244,6066130757198157026),
(8,3699419829,'fprt_north',35,0.5,'NRVOBM/nms/freeportnorth_explored.dds','NRVOBM/nms/freeportnorth_unexplored.dds',-179.19,-422.78,367.82,-11.37,-179.19,-422.78,367.82,-11.37,13615952927484414305,5455723309099852648),
(9,2855219261,'fprt_hood06',35,0.5,'NRVOBM/nms/freeportscaleyard_explored.dds','NRVOBM/nms/freeportscaleyard_unexplored.dds',-269.5,-123.97,214.44,240.8,-269.5,-123.97,214.44,240.8,9136914063004984589,13210495355421380022),
(10,1863868178,'fprt_south',35,0.5,'NRVOBM/nms/freeportsouth_explored.dds','NRVOBM/nms/freeportsouth_unexplored.dds',-188.17,40.52,360.64,449.48,-188.17,40.52,360.64,449.48,6287736685678233586,12424845592658234555),
(11,1692523675,'fprt_hood02',35,0.5,'NRVOBM/nms/freeportstonestairbyway_explored.dds','NRVOBM/nms/freeportstonestairbyway_unexplored.dds',-167.84,-157.1,164.91,89.21,-167.84,-157.1,164.91,89.21,9102244713137005177,17181146217504603163),
(12,2145507742,'fprt_adv01_sunken',35,0.5,'NRVOBM/nms/freeportsunkencity_explored.dds','NRVOBM/nms/freeportsunkencity_unexplored.dds',-268.89,-177.17,250.19,202.49,-268.89,-177.17,250.19,202.49,11201985807363065839,131908586403301389),
(13,736913751,'fprt_hood03',35,0.5,'NRVOBM/nms/freeporttemplestreet_explored.dds','NRVOBM/nms/freeporttemplestreet_unexplored.dds',-318.06,-122.85,233.45,290.97,-318.06,-122.85,233.45,290.97,9437209823055117782,16161684958939241492),
(14,2996805099,'commonlands',100,1,'NRVOBM/nms/commonlands_explored.dds','NRVOBM/nms/commonlands_unexplored.dds',-1751.35,-1300.12,1671.39,1289.76,-1751.35,-1300.12,1671.39,1289.76,16327872918514164936,17372200879931327209),
(15,1216993332,'fprt_adv02_graveyard',35,0.5,'NRVOBM/nms/freeportgraveyard_explored.dds','NRVOBM/nms/freeportgraveyard_unexplored.dds',-207.48,-161.07,242.19,165.89,-207.48,-161.07,242.19,165.89,10552204627275247213,15742044646771191048),
(16,4220558408,'fprt_adv04_ruins',35,0.5,'NRVOBM/nms/freeporttheruins_explored.dds','NRVOBM/nms/freeporttheruins_unexplored.dds',-130.56,-62.18,267.03,236.56,-130.56,-62.18,267.03,236.56,15556021436831344316,3128139745008385205),
(17,2515694938,'fprt_adv03_sprawl',35,0.5,'NRVOBM/nms/freeportthesprawl_explored.dds','NRVOBM/nms/freeportthesprawl_unexplored.dds',-185.04,-119.14,213.28,181.75,-185.04,-119.14,213.28,181.75,3289502242023864482,3819518046652854616),
(18,520317988,'fprt_west',35,0.5,'NRVOBM/nms/freeportwest_explored.dds','NRVOBM/nms/freeportwest_unexplored.dds',-508.91,-170.01,40.31,241.36,-508.91,-170.01,40.31,241.36,1963794546232365483,10588895289567876865),
(19,3334402394,'exp01_cty_majdul',35,0.5,'NRVOBM/nms/majdul_explored.dds','NRVOBM/nms/majdul_unexplored.dds',-348.09,-285.92,433.31,301.91,-348.09,-285.92,433.31,301.91,627041298884356077,5859392435652377563),
(20,3147601995,'exp01_rgn_sinking_sands_0',100,1,'NRVOBM/nms/sinkingsandsnorth_explored.dds','NRVOBM/nms/sinkingsandsnorth_unexplored.dds',-769.25,-1765.56,2316.81,550.98,-769.25,-1765.56,2316.81,270,5808151331377710742,5451386280516143234),
(21,3147601995,'exp01_rgn_sinking_sands_1',100,1,'NRVOBM/nms/sinkingsandssouth_explored.dds','NRVOBM/nms/sinkingsandssouth_unexplored.dds',-769.9,-923.51,2323.59,1395.9,-769.9,270,2323.59,1395.9,4388730675160386350,1820563360386611543),
(22,1472490641,'exp01_rgn_pillars_of_flame',100,1,'NRVOBM/nms/pillarsofflame_explored.dds','NRVOBM/nms/pillarsofflame_unexplored.dds',-2263.39,-1833.15,842.59,499.74,-2263.39,-1833.15,842.59,499.74,8133749639445806182,12597781589928503505),
(23,3638505046,'everfrost',100,1,'NRVOBM/nms/everfrost_explored.dds','NRVOBM/nms/everfrost_unexplored.dds',-1480.2,-2006.18,1667.63,340.46,-1480.2,-2006.18,1667.63,340.46,10806247368961295184,5316855380603212918),
(24,80848352,'exp03_rgn_butcherblock',200,1,'NRVOBM/nms/butcherblock_explored.dds','NRVOBM/nms/butcherblock_unexplored.dds',-1822.26,-765.3,1242.99,1647.32,-1822.26,-765.3,1242.99,1647.32,16986724152149385011,6790066804192744707),
(25,2774110503,'exp03_rgn_greater_faydark_0',150,0.5,'NRVOBM/nms/greaterfaydark_explored.dds','NRVOBM/nms/greaterfaydark_unexplored.dds',-908.35,-920.2,1552.5,926.59,-908.35,-920.2,1552.5,926.59,16444705060225863816,13634656485568206622),
(26,2774110503,'exp03_rgn_greater_faydark_1',150,0.5,'NRVOBM/nms/kelethin_explored.dds','NRVOBM/nms/kelethin_unexplored.dds',-712.88,-14.75,50.05,556.06,-712.88,-14.75,50.05,556.06,7796644633907824278,3634599199700320310),
(27,2774110503,'exp03_rgn_greater_faydark_2',150,0.5,'NRVOBM/nms/kelethin_explored.dds','NRVOBM/nms/kelethin_unexplored.dds',-712.88,-14.75,50.05,556.06,-615,224,-479,335,7796644633907824278,3634599199700320310),
(28,2774110503,'exp03_rgn_greater_faydark_3',150,0.5,'NRVOBM/nms/kelethin_explored.dds','NRVOBM/nms/kelethin_unexplored.dds',-712.88,-14.75,50.05,556.06,-450,300,-179,510,7796644633907824278,3634599199700320310),
(29,2949530798,'exp03_rgn_lesser_faydark',150,1,'NRVOBM/nms/lesserfaydark_explored.dds','NRVOBM/nms/lesserfaydark_unexplored.dds',-1212.94,-780.12,981.6,872.1,-1212.94,-780.12,981.6,872.1,6416689908854533881,17799713797570155618),
(30,2466122887,'exp03_rgn_loping_plains',150,1,'NRVOBM/nms/lopingplains_explored.dds','NRVOBM/nms/lopingplains_unexplored.dds',-965.07,-728.71,925.52,685.62,-965.07,-728.71,925.52,685.62,6114161135949193740,15282590855742392967),
(31,1672476788,'exp03_rgn_steamfont',100,1,'NRVOBM/nms/steamfont_explored.dds','NRVOBM/nms/steamfont_unexplored.dds',-470.72,259.11,1707.27,1889.73,-470.72,259.11,1707.27,1889.73,6585041603798635248,12765847214945532686),
(32,2620122292,'feerrott',100,1,'NRVOBM/nms/feerrott_explored.dds','NRVOBM/nms/feerrott_unexplored.dds',-479.32,-477.66,2271.27,1606.99,-479.32,-477.66,2271.27,1606.99,9934530746509178878,15376862988231080656),
(33,3216867334,'adv04_rgn_mystic_lake',100,1,'NRVOBM/nms/mystic_lake_explored.dds','NRVOBM/nms/mystic_lake_unexplored.dds',-477.83,-290.5,652.73,560.4,-477.83,-290.5,652.73,560.4,17065587528787906079,7440120844361720746),
(34,3789723549,'adv04_rgn_village',100,1,'NRVOBM/nms/mystic_lake_village_explored.dds','NRVOBM/nms/mystic_lake_village_unexplored.dds',-547.84,-493.94,612.05,380.2,-547.84,-493.94,612.05,380.2,2324712397108041533,4339790570666083225),
(35,606080845,'antonica',100,1,'NRVOBM/nms/antonica_explored.dds','NRVOBM/nms/antonica_unexplored.dds',-652.63,-1178.98,2910.01,1526.14,-652.63,-1178.98,2910.01,1526.14,9696150041059803081,6339337691777724671),
(36,1796499030,'qey_village04',35,0.5,'NRVOBM/nms/qeynoscastleviewhamlet_explored.dds','NRVOBM/nms/qeynoscastleviewhamlet_unexplored.dds',-1012.9,-312.79,-553.08,41.48,-1012.9,-312.79,-553.08,41.48,15462632759483396449,867966370954510497),
(37,1977002648,'qey_village03',35,0.5,'NRVOBM/nms/qeynosgreystoneyard_explored.dds','NRVOBM/nms/qeynosgreystoneyard_unexplored.dds',-1104.84,-289.78,-649.27,54.27,-1104.84,-289.78,-649.27,54.27,14219950055086169880,2803156202057389600),
(38,2051421555,'qey_village01',35,0.5,'NRVOBM/nms/qeynosnettlevillehovel_explored.dds','NRVOBM/nms/qeynosnettlevillehovel_unexplored.dds',-884.86,153.19,-403.2,513.58,-884.86,153.19,-403.2,513.58,15435981793457631353,15965042855920104932),
(39,1321576746,'qey_north_0',35,0.5,'NRVOBM/nms/qeynosnorth1_explored.dds','NRVOBM/nms/qeynosnorth1_unexplored.dds',-634.49,-134.62,-165.38,212.35,-634.49,-111.5,-165.38,212.35,1593568053289547433,10364039492447242135),
(40,1321576746,'qey_north_1',35,0.5,'NRVOBM/nms/qeynosnorth2_explored.dds','NRVOBM/nms/qeynosnorth2_unexplored.dds',-632.23,-406.43,-163.52,-54.73,-632.23,-406.43,-163.52,-111.5,8662284756197645628,16890549110374680397),
(41,798652325,'qey_adv01_oakmyst',35,0.5,'NRVOBM/nms/qeynosoakmystforest_explored.dds','NRVOBM/nms/qeynosoakmystforest_unexplored.dds',-1177.5,-462.25,-605.39,-33.11,-1177.5,-462.25,-605.39,-33.11,17204718708737063489,16748353685447147271),
(42,2292693789,'qey_harbor',35,0.5,'NRVOBM/nms/qeynosharbor_explored.dds','NRVOBM/nms/qeynosharbor_unexplored.dds',-1044.11,-155.04,-586.95,188.59,-1044.11,-155.04,-586.95,188.59,4420958767950396073,6537548439458091712),
(43,590283973,'qey_south',35,0.5,'NRVOBM/nms/qeynossouth_explored.dds','NRVOBM/nms/qeynossouth_unexplored.dds',-794.7,9.99,-336.22,354.07,-794.7,9.99,-336.22,354.07,3203350283198674362,5435883873871528381),
(44,2423293410,'qey_village02',35,0.5,'NRVOBM/nms/qeynosstarcrestcommune_explored.dds','NRVOBM/nms/qeynosstarcrestcommune_unexplored.dds',-994.1,133.09,-534.37,477.61,-994.1,133.09,-534.37,477.61,17000969402592380513,2684731269491297199),
(45,1658537518,'qey_village06',35,0.5,'NRVOBM/nms/qeynosbaubbleshire_explored.dds','NRVOBM/nms/qeynosbaubbleshire_unexplored.dds',-1202.29,-731.03,-545.37,-218.19,-1202.29,-731.03,-545.37,-218.19,176299128319668806,2049429213224763607),
(46,598564841,'qey_elddar',35,0.5,'NRVOBM/nms/qeynoselddargrove_explored.dds','NRVOBM/nms/qeynoselddargrove_unexplored.dds',-1004.46,-588.61,-428.61,-152.51,-1004.46,-588.61,-428.61,-152.51,174604223581131048,3008929186351491332),
(47,2847238067,'qey_adv02_ruins',35,0.5,'NRVOBM/nms/qeynosforestruins_explored.dds','NRVOBM/nms/qeynosforestruins_unexplored.dds',-1463.14,-1000.01,-675.87,-415.73,-1463.14,-1000.01,-675.87,-415.73,1282097909803057147,17471212299590345875),
(48,226232511,'qey_adv04_bog',35,0.5,'NRVOBM/nms/qeynospeatbog_explored.dds','NRVOBM/nms/qeynospeatbog_unexplored.dds',-936.08,336.3,-463.13,692.21,-936.08,336.3,-463.13,692.21,16743122741266783850,14013686924212037841),
(49,3713103859,'steppes',100,1,'NRVOBM/nms/thunderingsteppes_explored.dds','NRVOBM/nms/thunderingsteppes_unexplored.dds',-2573.44,-1205.21,1618.27,1966.47,-2573.44,-1205.21,1618.27,1966.47,1189019206961727173,14242711281201375492),
(50,1778622548,'qey_village05',35,0.5,'NRVOBM/nms/qeynoswillowwood_explored.dds','NRVOBM/nms/qeynoswillowwood_unexplored.dds',-1258.05,-892.88,-499.3,-310.57,-1258.05,-892.88,-499.3,-310.57,9150772007208460243,5398585900817023960),
(51,1120935014,'exp04_rgn_fens_of_nathsar',150,1,'NRVOBM/nms/fens_explored.dds','NRVOBM/nms/fens_unexplored.dds',-2943.84,-2995.24,4711.95,2734.79,-2943.84,-2995.24,4711.95,2734.79,4748445054443799500,13038592193461676513),
(52,803025503,'exp04_rgn_timorous_deep_0',150,0.5,'NRVOBM/nms/timorousdeep_explored.dds','NRVOBM/nms/timorousdeep_unexplored.dds',-3264.41,-956.91,730.29,2041.62,-3264.41,-956.91,730.29,2041.62,8594803996397212170,16583833509182073751),
(53,803025503,'exp04_rgn_timorous_deep_1',150,0.5,'NRVOBM/nms/gorowyntop_explored.dds','NRVOBM/nms/gorowyntop_unexplored.dds',-2890.45,992.8,-2339,1406.25,-2890.45,1018,-2205,1372,7318396749680160946,10506488850154391603),
(54,803025503,'exp04_rgn_timorous_deep_2',150,0.5,'NRVOBM/nms/gorowynbottom_explored.dds','NRVOBM/nms/gorowynbottom_unexplored.dds',-2890.45,992.8,-2339,1406.25,-2783,1137,-2385,1373,17577488901259245340,17648099873460854204),
(55,1843950258,'exp04_rgn_jarsath_wastes',150,1,'NRVOBM/nms/jarsath_explored.dds','NRVOBM/nms/jarsath_unexplored.dds',-2600.13,-2055.96,4096.49,3081.38,-2600.13,-2055.96,4096.49,3081.38,6309459621313500911,5469397549594442926),
(56,3698519862,'exp04_rgn_kunzar_jungle',150,1,'NRVOBM/nms/kunzar_explored.dds','NRVOBM/nms/kunzar_unexplored.dds',-2373.98,-1567.05,1925.73,1704.59,-2373.98,-1567.05,1925.73,1704.59,15064603935973368680,1065628830467543370),
(57,50574630,'exp04_rgn_kylong_plains',150,1,'NRVOBM/nms/kylong_explored.dds','NRVOBM/nms/kylong_unexplored.dds',-2870.96,-3587,3170.91,927.03,-2870.96,-3587,3170.91,927.03,6732068156651055471,702674427380517695),
(58,1238692603,'lavastorm',100,1,'NRVOBM/nms/lavastorm_explored.dds','NRVOBM/nms/lavastorm_unexplored.dds',-797.12,-822.96,1328.66,745.33,-797.12,-822.96,1328.66,745.33,4778084254654460528,10357358143206496540),
(59,540361188,'exp05_rgn_innothule_0',150,1,'NRVOBM/nms/Innothule_bottom_explored.dds','NRVOBM/nms/Innothule_bottom_unexplored.dds',-2871.3,-1563.66,3145.39,3011.64,-2871.3,-1563.66,3145.39,3011.64,7976594891636730107,12400329629261304445),
(60,540361188,'exp05_rgn_innothule_1',150,1,'NRVOBM/nms/Innothule_top_explored.dds','NRVOBM/nms/Innothule_top_unexplored.dds',-2951.74,-1581.67,3193.58,3002.03,-2951.74,-1581.67,3193.58,3002.03,7977227565062952700,18174869680104535186),
(61,3801547714,'exp02_rgn_realm_of_twilight',100,1,'NRVOBM/nms/realmoftwilight_explored.dds','NRVOBM/nms/realmoftwilight_unexplored.dds',-1490.48,-1181.85,1693.79,1216.61,-1490.48,-1181.85,1693.79,1216.61,4365228348667727585,13795972394651300598),
(62,2413690345,'exp02_rgn_realm_of_dawn',100,1,'NRVOBM/nms/realmofdawn_explored.dds','NRVOBM/nms/realmofdawn_unexplored.dds',-1274.45,-963.48,1384.82,1045.41,-1274.45,-963.48,1384.82,1045.41,3480121933232246843,17172823087655282605),
(63,4114060132,'exp02_rgn_realm_of_night',100,1,'NRVOBM/nms/realmofnight_explored.dds','NRVOBM/nms/realmofnight_unexplored.dds',-1536.85,-984.43,1543.17,1326.63,-1536.85,-984.43,1543.17,1326.63,7922868148507137580,3514434409054901812),
(64,456626312,'rivervale',100,1,'NRVOBM/nms/rivervale_explored.dds','NRVOBM/nms/rivervale_unexplored.dds',-1622.79,-1445.35,2332.72,1505.69,-1622.79,-1445.35,2332.72,1505.69,6962042073411490376,7938990975975226834),
(65,2763371011,'enchanted',100,1,'NRVOBM/nms/Enchantedlands_explored.dds','NRVOBM/nms/Enchantedlands_unexplored.dds',-919.73,-1398.81,1263.92,238.36,-919.73,-1398.81,1263.92,238.36,17497270808375111069,13340729561896321954),
(66,2782496766,'orcishwastes',100,1,'NRVOBM/nms/zek_explored.dds','NRVOBM/nms/zek_unexplored.dds',-1131.55,-1016.4,993.59,570.54,-1131.55,-1016.4,993.59,570.54,14881116540456471491,17890726624561211948),
(67,2567809289,'halas_0',50,0.5,'NRVOBM/nms/hallas_explored.dds','NRVOBM/nms/hallas_unexplored.dds',-2060.31,-1490.01,1817.4,1412.89,-5000,-5000,5000,5000,2786678981700087224,6249938391497124718),
(68,2567809289,'halas_1',50,0.5,'NRVOBM/nms/hallas_cave_explored.dds','NRVOBM/nms/hallas_cave_unexplored.dds',-571.5,-283.73,525.59,538.26,-288,-107,287,334,10500156960146780432,11984741782918218328),
(69,2567809289,'halas_2',50,0.5,'NRVOBM/nms/hallas_town_explored.dds','NRVOBM/nms/hallas_town_unexplored.dds',-192.07,-289.52,891.52,513.72,216,-218,408,-22,1416647764989539994,1416647764989539994),
(70,2567809289,'halas_3',50,0.5,'NRVOBM/nms/hallas_town_explored.dds','NRVOBM/nms/hallas_town_unexplored.dds',-192.07,-289.52,891.52,513.72,270,-54,460,353,1416647764989539994,1416647764989539994),
(71,3861182166,'battleground_iksar_ruins_0',0,0,'NRVOBM/nms/battlegrounds_ctf_explored.dds','NRVOBM/nms/battlegrounds_ctf_explored.dds',-479,-370,439,328,-5000,-5000,5000,5000,12985036808671302696,12985036808671302696),
(72,119032140,'battleground_gears_of_klakanon_0',0,0,'NRVOBM/nms/battlegrounds_relic_explored.dds','NRVOBM/nms/battlegrounds_relic_explored.dds',-85,-59,84,65,-5000,-5000,5000,5000,14706693216500816344,14706693216500816344),
(73,2500428036,'battleground_realm_of_prexus_0',0,0,'NRVOBM/nms/battlegrounds_nodes_explored.dds','NRVOBM/nms/battlegrounds_nodes_explored.dds',-624,-470,614,462,-5000,-5000,5000,5000,14767813154843060257,14767813154843060257),
(74,2567809289,'halas_2',50,0.5,'NRVOBM/nms/hallas_town_explored.dds','NRVOBM/nms/hallas_town_explored.dds',-192.07,-289.53,891.52,513.73,216,-218,408,-22,1416647764989539994,1416647764989539994),
(75,2567809289,'halas_3',50,0.5,'NRVOBM/nms/hallas_town_explored.dds','NRVOBM/nms/hallas_town_explored.dds',-192.07,-289.53,891.52,513.73,270,-54,460,353,1416647764989539994,1416647764989539994),
(76,803025503,'exp04_rgn_timorous_deep_2',150,0.5,'NRVOBM/nms/gorowyntop_explored.dds','NRVOBM/nms/gorowyntop_unexplored.dds',-2890.45,992.8,-2339,1406.25,-2783,1137,-2385,1373,7318396749680160946,10506488850154391603),
(77,2224654112,'freeport_combined',35,0.5,'NRVOBM/nms/freeport_explored.dds','NRVOBM/nms/freeport_explored.dds',-461,-392,517,342,-1500,-1500,1500,1500,7657417192443711689,7657417192443711689),
(78,1143602509,'exp06_rgn_odus_north',150,1,'NRVOBM/nms/odus_north_explored.dds','NRVOBM/nms/odus_north_unexplored.dds',-1866,-860,2435,2331,-1296,-889,1139,1486,4193934237649099649,8355002581792198744),
(79,291437850,'exp06_rgn_odus_south_0',150,1,'NRVOBM/nms/odus_south_explored.dds','NRVOBM/nms/odus_south_unexplored.dds',-3220,382,2878,4957,-5000,-5000,5000,5000,5378341627346504265,17836069960944570576),
(80,291437850,'exp06_rgn_odus_south_1',150,1,'NRVOBM/nms/odus_cave_top_explored.dds','NRVOBM/nms/odus_cave_top_unexplored.dds',-1499,2971,-706,3565,-1499,2971,-706,3565,7189064107602066426,15689380470328731586),
(81,291437850,'exp06_rgn_odus_south_2',150,1,'NRVOBM/nms/odus_cave_bottom_explored.dds','NRVOBM/nms/odus_cave_bottom_unexplored.dds',-1499,2971,-706,3565,-1499,2971,-706,3565,10713589630524092140,7513375462749178008),
(82,291437850,'exp06_rgn_odus_south_3',150,1,'NRVOBM/nms/odus_south_explored.dds','NRVOBM/nms/odus_south_unexplored.dds',-3220,382,2878,4957,-1497,3268,-1383,3375,5378341627346504265,17836069960944570576),
(83,291437850,'exp06_rgn_odus_south_4',150,1,'NRVOBM/nms/odus_cave_explored.dds','NRVOBM/nms/odus_cave_unexplored.dds',-968,3372,-100,4019,-834.43,3485.5,-306.55,3925.95,11070526559645328143,2664448008597217482),
(84,907158877,'fprt_hood03',35,0.5,'NRVOBM/nms/freeporttemplestreet_explored.dds','NRVOBM/nms/freeporttemplestreet_unexplored.dds',-318.06,-122.85,233.45,290.97,-318.06,-122.85,233.45,290.97,9437209823055117782,16161684958939241492),
(85,3160691463,'exp07_rgn_great_divide_0',100,1,'NRVOBM/nms/great_divide_explored.dds','NRVOBM/nms/great_divide_unexplored.dds',-2960,-1316,1745,2132,-2920,-1265,1700,2090,15398375324763939407,14512176915715961905),
(86,3160691463,'exp07_rgn_great_divide_1',100,1,'NRVOBM/nms/great_divide_iceclad_explored.dds','NRVOBM/nms/great_divide_iceclad_unexplored.dds',75,-2927,2327,-1237,144,-2864,2266,-1300,12395935522050732296,14163990487889687947),
(87,3160691463,'exp07_rgn_great_divide_2',100,1,'NRVOBM/nms/tizmak_explored.dds','NRVOBM/nms/tizmak_unexplored.dds',23,-378,708,145,124,-279,641,7,5345382249830368354,7309631109865933654),
(88,1620258631,'exp07_rgn_eastern_wastes',100,1,'NRVOBM/nms/eastern_wastes_explored.dds','NRVOBM/nms/eastern_wastes_unexplored.dds',-3225,1624,1856,5465,-3225,1624,1856,5465,14379236195658250109,11061710627426383934),
(89,307291459,'exp07_dun_plane_of_war_0',0,0,'NRVOBM/nms/exp07_dun_plane_of_war.dds','NRVOBM/nms/exp07_dun_plane_of_war.dds',-1964,-1484,1640,1224,-2000,-2000,2000,2000,7098767948089097895,7098767948089097895),
(90,2753675974,'exp07_dun_plane_of_war_challenge_0',0,0,'NRVOBM/nms/exp07_dun_plane_of_war.dds','NRVOBM/nms/exp07_dun_plane_of_war.dds',-1964,-1484,1640,1224,-2000,-2000,2000,2000,7098767948089097895,7098767948089097895),
(91,2838840815,'exp07_dun_plane_of_war_raid_0',0,0,'NRVOBM/nms/exp07_dun_plane_of_war.dds','NRVOBM/nms/exp07_dun_plane_of_war.dds',-1964,-1484,1640,1224,-2000,-2000,2000,2000,7098767948089097895,7098767948089097895),
(92,854639842,'exp07_dun_drunder_sullon_spire_0',0,0,'NRVOBM/nms/exp07_dun_drunder.dds','NRVOBM/nms/exp07_dun_drunder.dds',-175,-142,185,125,-2000,-2000,2000,2000,276240980989650788,276240980989650788),
(93,728095085,'exp07_dun_drunder_sullon_spire_raid_easy_0',0,0,'NRVOBM/nms/exp07_dun_drunder.dds','NRVOBM/nms/exp07_dun_drunder.dds',-175,-142,185,125,-2000,-2000,2000,2000,276240980989650788,276240980989650788),
(94,1136416641,'exp07_dun_drunder_sullon_spire_raid_0',0,0,'NRVOBM/nms/exp07_dun_drunder.dds','NRVOBM/nms/exp07_dun_drunder.dds',-175,-142,185,125,-2000,-2000,2000,2000,276240980989650788,276240980989650788),
(95,564686796,'exp07_dun_drunder_vuul_0',0,0,'NRVOBM/nms/exp07_dun_drunder.dds','NRVOBM/nms/exp07_dun_drunder.dds',-175,-142,185,125,-2000,-2000,2000,2000,276240980989650788,276240980989650788),
(96,701535643,'exp07_dun_drunder_tallon_stronghold_raid_easy_0',0,0,'NRVOBM/nms/exp07_dun_drunder.dds','NRVOBM/nms/exp07_dun_drunder.dds',-175,-142,185,125,-2000,-2000,2000,2000,276240980989650788,276240980989650788),
(97,3182672969,'exp07_dun_drunder_tallon_stronghold_raid_0',0,0,'NRVOBM/nms/exp07_dun_drunder.dds','NRVOBM/nms/exp07_dun_drunder.dds',-175,-142,185,125,-2000,-2000,2000,2000,276240980989650788,276240980989650788),
(98,3476613004,'exp07_dun_drunder_vallon_tower_raid_easy_0',0,0,'NRVOBM/nms/exp07_dun_drunder.dds','NRVOBM/nms/exp07_dun_drunder.dds',-175,-142,185,125,-2000,-2000,2000,2000,276240980989650788,276240980989650788),
(99,2709892608,'exp07_dun_drunder_vallon_tower_raid_0',0,0,'NRVOBM/nms/exp07_dun_drunder.dds','NRVOBM/nms/exp07_dun_drunder.dds',-175,-142,185,125,-2000,-2000,2000,2000,276240980989650788,276240980989650788),
(100,1264714838,'exp08_rgn_withered_lands',100,1,'NRVOBM/nms/withering_lands_explored.dds','NRVOBM/nms/withering_lands_unexplored.dds',-1331,-2589,4163,1496,-5000,-5000,5000,5000,17329737067621819744,16071790561860977455),
(101,1203853268,'exp08_dun_skyshrine_contested_0',0,0,'NRVOBM/nms/exp08_dun_skyshrine_market.dds','NRVOBM/nms/exp08_dun_skyshrine_market.dds',-446,-512,414,136,-41,-58,41,44,7125115118790191414,7125115118790191414),
(102,1203853268,'exp08_dun_skyshrine_contested_1',0,0,'NRVOBM/nms/exp08_dun_skyshrine_market.dds','NRVOBM/nms/exp08_dun_skyshrine_market.dds',-446,-512,414,136,-168,-147,168,-55,7125115118790191414,7125115118790191414),
(103,1203853268,'exp08_dun_skyshrine_contested_2',0,0,'NRVOBM/nms/exp08_dun_skyshrine_market.dds','NRVOBM/nms/exp08_dun_skyshrine_market.dds',-446,-512,414,136,-5000,-5000,5000,-58,7125115118790191414,7125115118790191414),
(104,1203853268,'exp08_dun_skyshrine_contested_3',0,0,'NRVOBM/nms/exp08_dun_skyshrine_arcane.dds','NRVOBM/nms/exp08_dun_skyshrine_arcane.dds',-670,-247,334,507,-5000,-144,-25,5000,1118540259285863273,1118540259285863273),
(105,1203853268,'exp08_dun_skyshrine_contested_4',0,0,'NRVOBM/nms/exp08_dun_skyshrine_capital.dds','NRVOBM/nms/exp08_dun_skyshrine_capital.dds',-379,-260,653,506,20,-146,5000,5000,15959633070977862839,15959633070977862839),
(106,538386786,'qeynos_combined02_0',35,1,'NRVOBM/nms/qeynos_new_explored.dds','NRVOBM/nms/qeynos_new_unexplored.dds',-1232,-555,-73,309,-5000,-165,5000,5000,16974777748194939734,9117030143180588321),
(107,538386786,'qeynos_combined02_1',35,1,'NRVOBM/nms/qeynos_new_explored.dds','NRVOBM/nms/qeynos_new_unexplored.dds',-1284,-579,-48,337,-5000,-5000,5000,-165,16974777748194939734,9117030143180588321),
(108,446027497,'exp09_dun_wurmbones_end_solo',0,0,'NRVOBM/nms/exp09_wurmbone_end.dds','NRVOBM/nms/exp09_wurmbone_end.dds',-1121,-828,672,527,-5000,-5000,5000,5000,10598390550327136336,10598390550327136336),
(109,1995393318,'exp09_dun_wurmbone_gulch_solo',0,0,'NRVOBM/nms/exp09_wurmbone_gulch.dds','NRVOBM/nms/exp09_wurmbone_gulch.dds',-493,-331,458,385,-5000,-5000,5000,5000,9670446201098646704,9670446201098646704),
(110,2143536644,'exp09_dun_wurmbones_end',0,0,'NRVOBM/nms/exp09_wurmbone_end.dds','NRVOBM/nms/exp09_wurmbone_end.dds',-1121,-828,672,527,-5000,-5000,5000,5000,10598390550327136336,10598390550327136336),
(111,1822738145,'exp09_dun_wurmbone_gulch',0,0,'NRVOBM/nms/exp09_wurmbone_gulch.dds','NRVOBM/nms/exp09_wurmbone_gulch.dds',-493,-331,458,385,-5000,-5000,5000,5000,9670446201098646704,9670446201098646704),
(112,2737465396,'exp09_dun_deepchelsith_solo',0,0,'NRVOBM/nms/exp09_chelsith.dds','NRVOBM/nms/exp09_chelsith.dds',-1793,-1380,931,664,-5000,-5000,5000,5000,8272329878726696270,8272329878726696270),
(113,2611216761,'exp09_dun_deepchelsith',0,0,'NRVOBM/nms/exp09_chelsith.dds','NRVOBM/nms/exp09_chelsith.dds',-1793,-1380,931,664,-5000,-5000,5000,5000,8272329878726696270,8272329878726696270),
(114,344863312,'exp09_rgn_eidolon_jungle',100,1,'NRVOBM/nms/exp09_eidolon_jungle_explored.dds','NRVOBM/nms/exp09_eidolon_jungle_unexplored.dds',-623,-686,2651,1767,-5000,-5000,5000,5000,17016420756975687580,11834282439838035541),
(115,82694744,'exp09_dun_temple_of_faceless_solo_0',0,0,'NRVOBM/nms/exp09_temple_of_faceless_south.dds','NRVOBM/nms/exp09_temple_of_faceless_south.dds',-104,-162,860,557,-5000,-46,5000,5000,15680989842487369893,15680989842487369893),
(116,82694744,'exp09_dun_temple_of_faceless_solo_1',0,0,'NRVOBM/nms/exp09_temple_of_faceless_north.dds','NRVOBM/nms/exp09_temple_of_faceless_north.dds',-98,-590,855,127,-5000,-5000,5000,46,8420950750948911609,8420950750948911609),
(117,3227813427,'exp09_dun_throne_of_fear_quest',0,0,'NRVOBM/nms/exp09_throne_of_fear.dds','NRVOBM/nms/exp09_throne_of_fear.dds',-449,-274,440,396,-5000,-5000,5000,5000,9218037391285322422,9218037391285322422),
(118,3649391170,'exp09_dun_temple_of_faceless_raid_0',0,0,'NRVOBM/nms/exp09_temple_of_faceless_south.dds','NRVOBM/nms/exp09_temple_of_faceless_south.dds',-104,-162,860,557,-5000,-46,5000,5000,15680989842487369893,15680989842487369893),
(119,3649391170,'exp09_dun_temple_of_faceless_raid_1',0,0,'NRVOBM/nms/exp09_temple_of_faceless_north.dds','NRVOBM/nms/exp09_temple_of_faceless_north.dds',-98,-590,855,127,-5000,-5000,5000,46,8420950750948911609,8420950750948911609),
(120,2955537692,'exp09_dun_throne_of_fear_solo',0,0,'NRVOBM/nms/exp09_throne_of_fear.dds','NRVOBM/nms/exp09_throne_of_fear.dds',-449,-274,440,396,-5000,-5000,5000,5000,9218037391285322422,9218037391285322422),
(121,3508339628,'exp09_dun_throne_of_fear',0,0,'NRVOBM/nms/exp09_throne_of_fear.dds','NRVOBM/nms/exp09_throne_of_fear.dds',-449,-274,440,396,-5000,-5000,5000,5000,9218037391285322422,9218037391285322422),
(122,3214732470,'exp09_dun_temple_of_faceless_0',0,0,'NRVOBM/nms/exp09_temple_of_faceless_south.dds','NRVOBM/nms/exp09_temple_of_faceless_south.dds',-104,-162,860,557,-5000,-46,5000,5000,15680989842487369893,15680989842487369893),
(123,3214732470,'exp09_dun_temple_of_faceless_1',0,0,'NRVOBM/nms/exp09_temple_of_faceless_north.dds','NRVOBM/nms/exp09_temple_of_faceless_north.dds',-98,-590,855,127,-5000,-5000,5000,46,8420950750948911609,8420950750948911609),
(124,1296399482,'exp09_rgn_plains_of_obol',100,1,'NRVOBM/nms/exp09_plains_of_obol_explored.dds','NRVOBM/nms/exp09_plains_of_obol_unexplored.dds',-1449,-866,1483,1331,-5000,-5000,5000,5000,2682842916150972796,16967132263527338798),
(125,939053947,'exp09_dun_drinals_ferry_solo',0,0,'NRVOBM/nms/exp09_drenals_ferry.dds','NRVOBM/nms/exp09_drenals_ferry.dds',-164,-140,160,108,-5000,-5000,5000,5000,16633786030976221656,16633786030976221656),
(126,3484386697,'exp09_dun_drinals_ferry',0,0,'NRVOBM/nms/exp09_drenals_ferry.dds','NRVOBM/nms/exp09_drenals_ferry.dds',-164,-140,160,108,-5000,-5000,5000,5000,16633786030976221656,16633786030976221656),
(127,2034232021,'exp09_dun_drinals_castle_raid_4',0,0,'NRVOBM/nms/exp09_drinals_castle_05.dds','NRVOBM/nms/exp09_drinals_castle_05.dds',-388,-411,324,125,-5000,-5000,5000,5000,187582067737357634,187582067737357634),
(128,2034232021,'exp09_dun_drinals_castle_raid_3',0,0,'NRVOBM/nms/exp09_drinals_castle_04.dds','NRVOBM/nms/exp09_drinals_castle_04.dds',-390,-513,322,21,-5000,-5000,5000,5000,12213601451163227976,12213601451163227976),
(129,2034232021,'exp09_dun_drinals_castle_raid_2',0,0,'NRVOBM/nms/exp09_drinals_castle_03.dds','NRVOBM/nms/exp09_drinals_castle_03.dds',-299,-229,295,216,-5000,-5000,5000,5000,17984566265797150987,17984566265797150987),
(130,2034232021,'exp09_dun_drinals_castle_raid_1',0,0,'NRVOBM/nms/exp09_drinals_castle_02.dds','NRVOBM/nms/exp09_drinals_castle_02.dds',-298,-229,293,212,-5000,-5000,5000,5000,15921122684686867078,15921122684686867078),
(131,2034232021,'exp09_dun_drinals_castle_raid_0',0,0,'NRVOBM/nms/exp09_drinals_castle_01.dds','NRVOBM/nms/exp09_drinals_castle_01.dds',-145,-207,158,21,-5000,-5000,5000,5000,9887787943210833918,9887787943210833918),
(132,1724618204,'fprt_hood06',35,0.5,'NRVOBM/nms/freeportscaleyard_explored.dds','NRVOBM/nms/freeportscaleyard_unexplored.dds',-269.5,-123.97,214.44,240.8,-269.5,-123.97,214.44,240.8,9136914063004984589,13210495355421380022),
(133,1782493420,'fprt_hood05',35,0.5,'NRVOBM/nms/freeportlongshadowalley_explored.dds','NRVOBM/nms/freeportlongshadowalley_unexplored.dds',-185.63,-147.51,165.21,126.03,-185.63,-147.51,165.21,126.03,17184580992826923618,13923871875585603012),
(134,2855298071,'exp09_dun_drinals_castle_4',0,0,'NRVOBM/nms/exp09_drinals_castle_05.dds','NRVOBM/nms/exp09_drinals_castle_05.dds',-388,-411,324,125,-5000,-5000,5000,5000,187582067737357634,187582067737357634),
(135,1296089602,'qey_village05_revamp',0,0,'NRVOBM/nms/qeynoswillowwood_explored.dds','NRVOBM/nms/qeynoswillowwood_unexplored.dds',-1258.05,-892.88,-499.3,-310.57,-1258.05,-892.88,-499.3,-310.57,9150772007208460243,5398585900817023960),
(136,3678731920,'qey_village06_revamp',0,0,'NRVOBM/nms/qeynosbaubbleshire_explored.dds','NRVOBM/nms/qeynosbaubbleshire_unexplored.dds',-1202.29,-731.03,-545.37,-218.19,-1202.29,-731.03,-545.37,-218.19,176299128319668806,2049429213224763607),
(137,43963313,'qey_village04_revamp',0,0,'NRVOBM/nms/qeynoscastleviewhamlet_explored.dds','NRVOBM/nms/qeynoscastleviewhamlet_unexplored.dds',-1012.9,-312.79,-553.08,41.48,-1012.9,-312.79,-553.08,41.48,15462632759483396449,867966370954510497),
(138,2499556381,'qey_village03_revamp',0,0,'NRVOBM/nms/qeynosgreystoneyard_explored.dds','NRVOBM/nms/qeynosgreystoneyard_unexplored.dds',-1104.84,-289.78,-649.27,54.27,-1104.84,-289.78,-649.27,54.27,14219950055086169880,2803156202057389600),
(139,2988135420,'qeynos_combined01',35,1,'NRVOBM/nms/qeynos_new_explored.dds','NRVOBM/nms/qeynos_new_unexplored.dds',-1247,-565,-74,310,-5000,-5000,5000,5000,16974777748194939734,9117030143180588321),
(140,3115626164,'qey_village02_revamp',0,0,'NRVOBM/nms/qeynosstarcrestcommune_explored.dds','NRVOBM/nms/qeynosstarcrestcommune_unexplored.dds',-994.1,133.09,-534.37,477.61,-994.1,133.09,-534.37,477.61,17000969402592380513,2684731269491297199),
(141,920040582,'qey_village01_revamp',0,0,'NRVOBM/nms/qeynosnettlevillehovel_explored.dds','NRVOBM/nms/qeynosnettlevillehovel_unexplored.dds',-884.86,153.19,-403.2,513.58,-884.86,153.19,-403.2,513.58,15435981793457631353,15965042855920104932),
(142,202164305,'exp07_dun_velks_forgotten_pools_0',0,0,'NRVOBM/nms/exp07_dun_forgotten_pools01.dds','NRVOBM/nms/exp07_dun_forgotten_pools01.dds',-540,-626,377,57,-1000,-1000,1000,1000,4424038280096058828,4424038280096058828),
(143,3696402977,'exp_07_thurgadin_velious',0,0,'NRVOBM/nms/thurgadin_explored.dds','NRVOBM/nms/thurgadin_explored.dds',-1105,-103,257,919,-1100,-200,300,900,1741793989802223335,1741793989802223335),
(144,348830090,'exp09_dun_sleepers_upper_0',0,0,'NRVOBM/nms/dun_sleepers_upper.dds','NRVOBM/nms/dun_sleepers_upper.dds',-873,-577,377,363,-5000,-5000,5000,5000,3868160118700218897,3868160118700218897),
(145,2855298071,'exp09_dun_drinals_castle_3',0,0,'NRVOBM/nms/exp09_drinals_castle_04.dds','NRVOBM/nms/exp09_drinals_castle_04.dds',-390,-513,322,21,-5000,-5000,5000,5000,12213601451163227976,12213601451163227976),
(146,2855298071,'exp09_dun_drinals_castle_2',0,0,'NRVOBM/nms/exp09_drinals_castle_03.dds','NRVOBM/nms/exp09_drinals_castle_03.dds',-299,-229,295,216,-5000,-5000,5000,5000,17984566265797150987,17984566265797150987),
(147,2855298071,'exp09_dun_drinals_castle_1',0,0,'NRVOBM/nms/exp09_drinals_castle_02.dds','NRVOBM/nms/exp09_drinals_castle_02.dds',-298,-229,293,212,-5000,-5000,5000,5000,15921122684686867078,15921122684686867078),
(148,2855298071,'exp09_dun_drinals_castle_0',0,0,'NRVOBM/nms/exp09_drinals_castle_01.dds','NRVOBM/nms/exp09_drinals_castle_01.dds',-145,-207,158,21,-5000,-5000,5000,5000,9887787943210833918,9887787943210833918),
(149,1357927069,'fprt_hood01',35,0.5,'NRVOBM/nms/freeportbigbend_explored.dds','NRVOBM/nms/freeportbigbend_unexplored.dds',-268.73,-156.94,241.76,233.74,-268.73,-156.94,241.76,233.74,13893361007639750321,13906198626671770666),
(150,450503637,'fprt_hood02',35,0.5,'NRVOBM/nms/freeportstonestairbyway_explored.dds','NRVOBM/nms/freeportstonestairbyway_unexplored.dds',-167.84,-157.1,164.91,89.21,-167.84,-157.1,164.91,89.21,9102244713137005177,17181146217504603163),
(151,4207549061,'fprt_hood04',35,0.5,'NRVOBM/nms/freeportbeggarscourt_explored.dds','NRVOBM/nms/freeportbeggarscourt_unexplored.dds',-225.8,-137.49,181.39,158.88,-225.8,-137.49,181.39,158.88,4800855641399099720,901758263814064518),
(152,348830090,'exp09_dun_sleepers_upper_1',0,0,'NRVOBM/nms/dun_sleepers_lair.dds','NRVOBM/nms/dun_sleepers_lair.dds',656,-420,1537,233,-5000,-5000,5000,5000,17281961401678138388,17281961401678138388),
(153,3190881085,'exp09_dun_sleepers_upper_raid_0',0,0,'NRVOBM/nms/dun_sleepers_upper.dds','NRVOBM/nms/dun_sleepers_upper.dds',-873,-577,377,363,-5000,-5000,5000,5000,3868160118700218897,3868160118700218897),
(154,3190881085,'exp09_dun_sleepers_upper_raid_1',0,0,'NRVOBM/nms/dun_sleepers_lair.dds','NRVOBM/nms/dun_sleepers_lair.dds',656,-420,1537,233,-5000,-5000,5000,5000,17281961401678138388,17281961401678138388),
(155,2608359373,'exp07_dun_tofs_lower_0',0,0,'NRVOBM/nms/exp07_dun_tofs_floor01.dds','NRVOBM/nms/exp07_dun_tofs_floor01.dds',-162,-151,154,85,-150,-300,150,300,8533223195127342865,8533223195127342865),
(156,2608359373,'exp07_dun_tofs_lower_1',0,0,'NRVOBM/nms/exp07_dun_tofs_floor02.dds','NRVOBM/nms/exp07_dun_tofs_floor02.dds',-241,-169,228,186,-150,-300,150,300,3969457324698211649,3969457324698211649),
(157,2608359373,'exp07_dun_tofs_lower_2',0,0,'NRVOBM/nms/exp07_dun_tofs_floor03.dds','NRVOBM/nms/exp07_dun_tofs_floor03.dds',-159,-117,149,114,-150,-300,150,300,13031235590626083639,13031235590626083639),
(158,2607359490,'exp07_dun_tofs_upper_0',0,0,'NRVOBM/nms/exp07_dun_tofs_floor04.dds','NRVOBM/nms/exp07_dun_tofs_floor04.dds',-133,-165,291,153,-150,-300,150,300,887812851746817802,887812851746817802),
(159,2607359490,'exp07_dun_tofs_upper_1',0,0,'NRVOBM/nms/exp07_dun_tofs_floor05.dds','NRVOBM/nms/exp07_dun_tofs_floor05.dds',-230,-193,212,142,-150,-300,150,300,6814662529044666474,6814662529044666474),
(160,2607359490,'exp07_dun_tofs_upper_2',0,0,'NRVOBM/nms/exp07_dun_tofs_floor06.dds','NRVOBM/nms/exp07_dun_tofs_floor06.dds',-275,-135,196,218,-150,-300,150,300,5826789502053469203,5826789502053469203),
(161,905538670,'exp07_dun_tofs_top_0',0,0,'NRVOBM/nms/exp07_dun_tofs_floor01.dds','NRVOBM/nms/exp07_dun_tofs_floor01.dds',-162,-151,154,85,-150,-300,150,300,8533223195127342865,8533223195127342865),
(162,905538670,'exp07_dun_tofs_top_1',0,0,'NRVOBM/nms/blank_map.dds','NRVOBM/nms/blank_map.dds',-179,-12,201,272,-150,-300,150,300,6089303624680826542,6089303624680826542),
(163,905538670,'exp07_dun_tofs_top_2',0,0,'NRVOBM/nms/exp07_dun_tofs_floor08.dds','NRVOBM/nms/exp07_dun_tofs_floor08.dds',-179,-90,150,154,-150,-300,150,300,2564313238147359990,2564313238147359990),
(164,1882371056,'exp_07_thurgadin_velious',150,0.5,'NRVOBM/nms/thurgadin_explored.dds','NRVOBM/nms/thurgadin_explored.dds',-1105,-103,257,919,-1100,-200,300,900,1741793989802223335,1741793989802223335),
(165,202164305,'exp07_dun_velks_forgotten_pools_1',0,0,'NRVOBM/nms/exp07_dun_forgotten_pools02.dds','NRVOBM/nms/exp07_dun_forgotten_pools02.dds',-3432,-2550,3130,2281,-2500,-2500,2500,2500,5240459448305127650,5240459448305127650),
(166,3994920284,'exp07_dun_velks_the_ascent_0',0,0,'NRVOBM/nms/exp07_dun_velkslab_the_ascent.dds','NRVOBM/nms/exp07_dun_velkslab_the_ascent.dds',-137,-485,705,151,-1000,-1000,1000,1000,11878982203057314982,11878982203057314982),
(167,3935624881,'exp07_dun_velks_fortress_0',0,0,'NRVOBM/nms/exp07_dun_kraytocs_fortess.dds','NRVOBM/nms/exp07_dun_kraytocs_fortess.dds',-189,-157,915,678,-1000,-1000,1000,1000,15908459665844101530,15908459665844101530),
(168,3760373257,'exp07_dun_kraytocs_fortress_0',0,0,'NRVOBM/nms/exp07_dun_kraytocs_fortess.dds','NRVOBM/nms/exp07_dun_kraytocs_fortess.dds',-189,-157,915,678,-1000,-1000,1000,1000,15908459665844101530,15908459665844101530),
(169,4159697226,'exp09_dun_sleepers_contested_0',0,0,'NRVOBM/nms/dun_sleepers_upper.dds','NRVOBM/nms/dun_sleepers_upper.dds',-873,-577,377,363,-5000,-5000,5000,5000,3868160118700218897,3868160118700218897),
(170,241080936,'exp07_dun_kael_throne_0',0,0,'NRVOBM/nms/exp07_dun_kaeldrakkel01.dds','NRVOBM/nms/exp07_dun_kaeldrakkel01.dds',-1109,290,1285,2098,32,451,228,1127,3603769704654017244,3603769704654017244),
(171,2656318491,'exp09_dun_sleepers_raid_0',0,0,'NRVOBM/nms/dun_sleepers_upper.dds','NRVOBM/nms/dun_sleepers_upper.dds',-873,-577,377,363,-5000,-5000,5000,5000,3868160118700218897,3868160118700218897),
(172,2656318491,'exp09_dun_sleepers_raid_2',0,0,'NRVOBM/nms/dun_sleepers_lower.dds','NRVOBM/nms/dun_sleepers_lower.dds',-501,-564,761,378,-5000,-5000,5000,5000,10162887799718315843,10162887799718315843),
(173,2656318491,'exp09_dun_sleepers_raid_1',0,0,'NRVOBM/nms/dun_sleepers_lair.dds','NRVOBM/nms/dun_sleepers_lair.dds',656,-420,1537,233,746,-147,1405,308,17281961401678138388,17281961401678138388),
(174,4159697226,'exp09_dun_sleepers_contested_2',0,0,'NRVOBM/nms/dun_sleepers_lower.dds','NRVOBM/nms/dun_sleepers_lower.dds',-501,-564,761,378,-5000,-5000,5000,5000,10162887799718315843,10162887799718315843),
(175,4159697226,'exp09_dun_sleepers_contested_1',0,0,'NRVOBM/nms/dun_sleepers_lair.dds','NRVOBM/nms/dun_sleepers_lair.dds',656,-420,1537,233,746,-147,1405,308,17281961401678138388,17281961401678138388),
(176,2853096630,'exp07_dun_kael_iceshard_keep_0',0,0,'NRVOBM/nms/exp07_dun_kaeldrakkel04.dds','NRVOBM/nms/exp07_dun_kaeldrakkel04.dds',72,-69,1058,675,-1000,-1000,1000,1000,11661461510227503106,11661461510227503106),
(177,1617785482,'exp09_dun_sleepers_lower_solo',0,0,'NRVOBM/nms/dun_sleepers_lower.dds','NRVOBM/nms/dun_sleepers_lower.dds',-501,-564,761,378,-5000,-5000,5000,5000,10162887799718315843,10162887799718315843),
(178,1830310931,'exp09_dun_sleepers_lower',0,0,'NRVOBM/nms/dun_sleepers_lower.dds','NRVOBM/nms/dun_sleepers_lower.dds',-501,-564,761,378,-5000,-5000,5000,5000,10162887799718315843,10162887799718315843),
(179,2777580771,'exp07_dun_kael_temple_zek_raid_easy_0',0,0,'NRVOBM/nms/exp07_dun_kaeldrakkel03.dds','NRVOBM/nms/exp07_dun_kaeldrakkel03.dds',-674,-3379,2851,-749,-91,-3233,2150,-1053,13778997396821898878,13778997396821898878),
(180,233038101,'exp07_dun_kael_temple_zek_raid_0',0,0,'NRVOBM/nms/exp07_dun_kaeldrakkel03.dds','NRVOBM/nms/exp07_dun_kaeldrakkel03.dds',-674,-3379,2851,-749,-91,-3233,2150,-1053,13778997396821898878,13778997396821898878),
(181,519055693,'exp07_dun_kael_throne_raid_easy_0',0,0,'NRVOBM/nms/exp07_dun_kaeldrakkel01.dds','NRVOBM/nms/exp07_dun_kaeldrakkel01.dds',-1109,290,1285,2098,32,451,228,1127,3603769704654017244,3603769704654017244),
(182,1585221530,'exp07_dun_kael_throne_raid_0',0,0,'NRVOBM/nms/exp07_dun_kaeldrakkel01.dds','NRVOBM/nms/exp07_dun_kaeldrakkel01.dds',-1109,290,1285,2098,32,451,228,1127,3603769704654017244,3603769704654017244),
(183,561709974,'exp07_dun_kael_temple_zek_0',0,0,'NRVOBM/nms/exp07_dun_kaeldrakkel03.dds','NRVOBM/nms/exp07_dun_kaeldrakkel03.dds',-674,-3379,2851,-749,-91,-3233,2150,-1053,13778997396821898878,13778997396821898878),
(184,1290963353,'exp07_dun_kael_drakkel_0',0,0,'NRVOBM/nms/exp07_dun_kaeldrakkel05.dds','NRVOBM/nms/exp07_dun_kaeldrakkel05.dds',-1,-573,2153,1050,770,-501,1544,940,16520645256069336079,16520645256069336079),
(185,1290963353,'exp07_dun_kael_drakkel_1',0,0,'NRVOBM/nms/exp07_dun_kaeldrakkel05.dds','NRVOBM/nms/exp07_dun_kaeldrakkel05.dds',-1,-573,2153,1050,765,-362,963,103,16520645256069336079,16520645256069336079),
(186,1290963353,'exp07_dun_kael_drakkel_2',0,0,'NRVOBM/nms/exp07_dun_kaeldrakkel06.dds','NRVOBM/nms/exp07_dun_kaeldrakkel06.dds',-511,-1427,1712,190,242,-1053,963,-76,16504038353869196008,16504038353869196008),
(187,1290963353,'exp07_dun_kael_drakkel_3',0,0,'NRVOBM/nms/exp07_dun_kaeldrakkel06.dds','NRVOBM/nms/exp07_dun_kaeldrakkel06.dds',-511,-1427,1712,190,963,-1053,1090,-405,16504038353869196008,16504038353869196008),
(188,1290963353,'exp07_dun_kael_drakkel_4',0,0,'NRVOBM/nms/exp07_dun_kaeldrakkel04.dds','NRVOBM/nms/exp07_dun_kaeldrakkel04.dds',72,-69,1058,675,505,-40,620,96,11661461510227503106,11661461510227503106),
(189,1290963353,'exp07_dun_kael_drakkel_5',0,0,'NRVOBM/nms/exp07_dun_kaeldrakkel04.dds','NRVOBM/nms/exp07_dun_kaeldrakkel04.dds',72,-69,1058,675,384,97,751,288,11661461510227503106,11661461510227503106),
(190,1290963353,'exp07_dun_kael_drakkel_6',0,0,'NRVOBM/nms/exp07_dun_kaeldrakkel04.dds','NRVOBM/nms/exp07_dun_kaeldrakkel04.dds',72,-69,1058,675,400,288,728,589,11661461510227503106,11661461510227503106),
(191,1290963353,'exp07_dun_kael_drakkel_7',0,0,'NRVOBM/nms/exp07_dun_kaeldrakkel01.dds','NRVOBM/nms/exp07_dun_kaeldrakkel01.dds',-1109,290,1285,2098,32,451,228,1127,3603769704654017244,3603769704654017244),
(192,1290963353,'exp07_dun_kael_drakkel_8',0,0,'NRVOBM/nms/exp07_dun_kaeldrakkel01.dds','NRVOBM/nms/exp07_dun_kaeldrakkel01.dds',-1109,290,1285,2098,-337,1127,587,1904,3603769704654017244,3603769704654017244),
(193,1290963353,'exp07_dun_kael_drakkel_9',0,0,'NRVOBM/nms/exp07_dun_kaeldrakkel02.dds','NRVOBM/nms/exp07_dun_kaeldrakkel02.dds',-1836,-940,616,947,-1740,-363,383,451,7568174142193434350,7568174142193434350),
(194,1290963353,'exp07_dun_kael_drakkel_10',0,0,'NRVOBM/nms/exp07_dun_kaeldrakkel02.dds','NRVOBM/nms/exp07_dun_kaeldrakkel02.dds',-1836,-940,616,947,305,-552,406,-31,7568174142193434350,7568174142193434350),
(195,1290963353,'exp07_dun_kael_drakkel_11',0,0,'NRVOBM/nms/exp07_dun_kaeldrakkel03.dds','NRVOBM/nms/exp07_dun_kaeldrakkel03.dds',-728,-3383,2865,-743,-91,-3233,2150,-1053,13778997396821898878,13778997396821898878);
/*!40000 ALTER TABLE `map_data` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-17 17:23:35

SET FOREIGN_KEY_CHECKS=1;
